class User:
    def __init__(self, id, gokstadmail, firstname, lastname, role, email2, email3, link):
        self.id = id
        self.gokstadmail = gokstadmail
        self.firstname = firstname
        self.lastname = lastname
        self.role = role
        self.email2 = email2
        self.email3 = email3
        self.link = link