from flask import Flask, redirect, render_template, request, session
from flask_session import Session
import requests
import jwt
import base64
import urllib3
from datetime import datetime, timezone
from dateutil import parser
from utility.user import User
from utility.event import Event
from utility.event_day import EventDay
from utility.assignment import Assignment
from utility.lecture import Lecture
from utility.examImplementation import ExamImplementation

# from helpers.program import Program, ProgramImplementation
# from helpers.course import Course, CourseImplementation
# import helpers.factory as factory #, programs_get_implementations

urllib3.disable_warnings()

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# MY GLOBAL VARIABLES
URLpre = "https://localhost:7042/api/v1/"

@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

@app.route("/")
def index():
    if "user" not in session or datetime.now() > session['token_expiration_dt']:        # timezone.utc
        session.clear()
    user = session["user"] if "user" in session else False

    return render_template("index.html", user=user)

@app.route("/login", methods=["POST"])
def login():
    gokstadmail = request.form.get("gokstadmail")
    password = request.form.get("password")

    data = {
        "GokstadEmail": gokstadmail,    # "nora.moe@gokstadakademiet.no",   johannes.andersen@gokstadakademiet.no, MZHlhk54 (1)
        "Password": password,           # "POGxar99"                        ole.larsen@gokstadakademiet.no, UQTyho81 (10)
    }

    url_ext = "login"
    url = URLpre + url_ext

    response = requests.post(url, verify=False, json=data)

    if not response.ok:
        err_msg = "Kunne ikke logge deg inn.\n Feil brukernavn og/eller passord."
        return render_template("index.html", err_msg=err_msg)

    token = response.text
    decoded_token = jwt.decode(token, options={'verify_signature': False})
    # print(decoded_token)

    expiration = decoded_token['exp']
    # expiration_datetime = datetime.utcfromtimestamp(expiration)
    expiration_datetime = datetime.fromtimestamp(expiration)
    gokmail = decoded_token["gokstademail"]
    first = decoded_token["firstname"]
    last = decoded_token["lastname"]
    id = decoded_token["id"]
    role = decoded_token["role"]
    email2 = decoded_token["email2"]
    email3 = decoded_token["email3"]
    link = decoded_token["link"]

    session["user"] = User(id, gokmail, first, last, role, email2, email3, link)
    session["token"] = token
    session['token_expiration'] = expiration
    session['token_expiration_dt'] = expiration_datetime

    return redirect("/")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

@app.route("/calendar")
def calendar():
    if "user" not in session or datetime.now() > session['token_expiration_dt']:        # timezone.utc
        session.clear()
        return redirect("/")
    user = session["user"]

    start_date = request.args.get('start')
    start = datetime.now().date()

    if start_date:
        start = parser.parse(start_date).date()    #, dayfirst=True
    today = start.strftime("%Y-%m-%d")
    num_days = request.args.get('num_days')
    if not num_days:
        num_days = 14
    else:
        num_days = int(num_days)

    headers = {"Authorization": f"Bearer {session['token']}"}

    url_ext = f"Event/User/{user.id}"
    url = URLpre + url_ext
    response = requests.get(url, verify=False, headers=headers)
    if response.ok:
        response = response.json()
        events = [Event(item['time'], item['underlyingId'], item['type'], item['typeEng'], item['courseImplementationId'],
                        item['courseImpCode'], item['courseImpName'], item['courseImplementationLink'], item['link']) for item in response]
        days = EventDay.make_days(start, num_days, events)
        return render_template("events.html", user=user, events=events, days=days, num_days=num_days, today=today)
    msg = f"Statuskode: {response.status_code}"
    return render_template("error.html", user=user, msg=msg, status=int(response.status_code))


@app.route("/Assignment/<int:id>")
def assignment_id(id):
    if "user" not in session or datetime.now() > session['token_expiration_dt']:        # timezone.utc
        session.clear()
        return redirect("/")
    user = session["user"]
    id = int(id)
    url_ext = f"Assignment/{id}"
    url = URLpre + url_ext

    headers = {"Authorization": f"Bearer {session['token']}"}
    response = requests.get(url, verify=False, headers=headers)
    if response.ok:
        as_dic = response.json()
        assignment = Assignment(as_dic['id'], as_dic['name'], as_dic['description'], as_dic['deadline'], as_dic['courseImplementationId'],
                                as_dic['courseImplementationCode'], as_dic['courseImplementationName'], as_dic['courseImplementationLink'],
                                as_dic['link'])
        return render_template("assignment.html", assignment=assignment, user=user)
    msg = f"Statuskode: {response.status_code}"
    return render_template("error.html", user=user, msg=msg, status=int(response.status_code))

@app.route("/Lecture/<int:id>")
def lecture_id(id):
    if "user" not in session or datetime.now() > session['token_expiration_dt']:        # timezone.utc
        session.clear()
        return redirect("/")
    user = session["user"]
    id = int(id)
    url_ext = f"Lecture/{id}"
    url = URLpre + url_ext

    headers = {"Authorization": f"Bearer {session['token']}"}
    response = requests.get(url, verify=False, headers=headers)
    if response.ok:
        as_dic = response.json()
        lecture = Lecture(as_dic['id'], as_dic['courseImplementationId'], as_dic['theme'], as_dic['description'],
                                as_dic['startTime'], as_dic['endTime'], as_dic['courseImplementationLink'],
                                as_dic['link'], as_dic['duration'], as_dic['courseImplementationName'], as_dic['courseImplementationCode'],
                                as_dic['teacherNames'])
        # id, courseImplementationId, theme, description, startTime, endTime,
        # courseImplementationLink, link, duration, courseImplementationName, courseImplementationCode
        return render_template("lecture.html", lecture=lecture, user=user)
    msg = f"Statuskode: {response.status_code}"
    return render_template("error.html", user=user, msg=msg, status=int(response.status_code))

@app.route("/ExamImplementation/<int:id>")
def examImplementation_id(id):
    if "user" not in session or datetime.now() > session['token_expiration_dt']:        # timezone.utc
        session.clear()
        return redirect("/")
    user = session["user"]
    id = int(id)
    url_ext = f"ExamImplementation/{id}"
    url = URLpre + url_ext

    headers = {"Authorization": f"Bearer {session['token']}"}
    response = requests.get(url, verify=False, headers=headers)
    if response.ok:
        as_dic = response.json()
        examImp = ExamImplementation(as_dic['id'], as_dic['examId'], as_dic['venueId'], as_dic['startTime'],
                                as_dic['endTime'], as_dic['category'], as_dic['durationHours'], as_dic['courseImplementationId'],
                                as_dic['courseImplementationName'], as_dic['courseImplementationCode'], as_dic['venueName'],
                                 as_dic['location'], as_dic['courseImplementationLink'], as_dic['venueLink'], as_dic['link'])
        # id, examId, venueId, startTime, endTime, category, durationHours, courseImplementationId,
        # courseImplementationName, courseImplementationCode, venueName, location,
        # courseImplementationLink, venueLink, link
        return render_template("examImplementation.html", examImp=examImp, user=user)
    msg = f"Statuskode: {response.status_code}"
    return render_template("error.html", user=user, msg=msg, status=int(response.status_code))

@app.errorhandler(404)
def page_not_found(error):
    code = "404 Not Found"
    user = None
    if "user" in session:
        user = session['user']
    return render_template('server_error.html', error=error, user=user, code=code), 404

@app.errorhandler(500)
def internal_server_error(error):
    code = "500 Internal Server Error"
    user = None
    if "user" in session:
        user = session['user']
    return render_template('server_error.html', error=error, user=user, code=code), 500
